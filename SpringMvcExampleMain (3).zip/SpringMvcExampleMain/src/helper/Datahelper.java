package helper;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Emp;

public class Datahelper {
	 Configuration cfg = new Configuration();
	SessionFactory sf;
	
	
	public void configure()
	{
		
		cfg.configure("hibernate.cfg.xml");
		sf= cfg.buildSessionFactory();
		
	  }
	public void insertOperation(Object o)
	  {
		    Session ses = sf.openSession();
			Transaction tx = ses.beginTransaction();
			ses.save(o);
			tx.commit();
			ses.close();
	  }
	public Object findOperation(Class c,int id)
	  {
		  Session ses = sf.openSession();
		  Object o = ses.get(c,id);
		  return o;
	  }
	public  void updateOperation(Object o1)
	  {
		   Session ses = sf.openSession();
		   Transaction tx = ses.beginTransaction();
		
			
			ses.update(o1);
			tx.commit();
			ses.close();
	  }
	public  void deleteOperation(Object o)
	  {
		  Session ses = sf.openSession();
		   Transaction tx = ses.beginTransaction();
		
			
			ses.delete(o);
			tx.commit();
			ses.close();
	  }
	 public Query selectOperation(String query)
	  {
		   Session ses = sf.openSession();
			Query q = ses.createQuery(query);
			
			return q;
	  }
      public void closeConn()
      {
    	  sf.close();
      }
}
