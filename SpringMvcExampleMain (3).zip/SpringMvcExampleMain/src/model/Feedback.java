package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="feedback")
public class Feedback {
@Id
private int feedid;
@Column
private String userid;
@Column
private String feeddesc;
@Column
private String faculty;
public int getFeedid() {
	return feedid;
}
public void setFeedid(int feedid) {
	this.feedid = feedid;
}
public String getUserid() {
	return userid;
}
public void setUserid(String userid) {
	this.userid = userid;
}
public String getFeeddesc() {
	return feeddesc;
}
public void setFeeddesc(String feeddesc) {
	this.feeddesc = feeddesc;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}


}
