package controller;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import helper.Datahelper;
import model.Admin;
import model.Reg;
@Controller
public class RegController {
	@RequestMapping("regload")
	public ModelAndView empload()
	{
	return new ModelAndView("regview", "command", new Reg());
	}
	
	@RequestMapping(value="reglogic",method=RequestMethod.POST)
    public ModelAndView empLogic(@ModelAttribute("SpringMvcExampleMain")Reg e)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		obj1.insertOperation(e);
		obj1.closeConn();
		ModelAndView obj=new ModelAndView("regview","command",new Reg());

		obj.addObject("res", "Registration Successfully ");

    	return obj;
    }
	@RequestMapping("userlogin")
	public ModelAndView loginDemo(@ModelAttribute("SpringMvcExampleMain")Reg s, ModelMap mp)
	{
		if(s!=null)
		{
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Query q = ses.createQuery("from Reg e where e.username=? and e.password=?");
			q.setString(0,s.getUsername());
			q.setString(1,s.getPassword());
			List lst = q.list();
			if(lst.size()>0)
			{
				return new ModelAndView("redirect:feedload.do");
			}
			else
			{
				mp.addAttribute("key","Invalid userid and password");
				return new ModelAndView("userlogin","command",new Reg());
				
			}
		}
		mp.addAttribute("key","");
		return new ModelAndView("userlogin","command",new Reg());
	}
	
}
