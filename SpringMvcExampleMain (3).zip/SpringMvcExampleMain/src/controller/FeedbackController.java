package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import helper.Datahelper;
import model.Admin;
import model.Feedback;
@Controller
public class FeedbackController {
	@RequestMapping("feedload")
	public ModelAndView empload(HttpServletRequest request)
	{
		
	     return new ModelAndView("feedview", "command", new Feedback());
	
	}
	
	@RequestMapping(value="feedlogic",method=RequestMethod.POST)
    public ModelAndView empLogic(@ModelAttribute("SpringMvcExampleMain")Feedback e)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		obj1.insertOperation(e);
		obj1.closeConn();
		ModelAndView obj=new ModelAndView("feedview","command",new Feedback());

		obj.addObject("res", "Feedback submitted Successfully ");

    	return obj;
    }
	
	
	
}
