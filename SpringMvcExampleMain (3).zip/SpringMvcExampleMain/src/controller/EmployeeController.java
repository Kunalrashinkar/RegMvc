package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Emp;
import helper.*;

@Controller
public class EmployeeController {
 
	@RequestMapping("empload")
	public ModelAndView empload()
	{
	return new ModelAndView("empview", "command", new Emp());
	}
	
	@RequestMapping(value="emplogic",method=RequestMethod.POST)
    public ModelAndView empLogic(@ModelAttribute("SpringMvcExampleMain")Emp e)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		obj1.insertOperation(e);
		obj1.closeConn();
		ModelAndView obj=new ModelAndView("empview","command",new Emp());

		obj.addObject("res", "Data Inserted Successfully ");

    	return obj;
    }
	
	
	@RequestMapping("showemp")
    public ModelAndView showEmp()
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		List lst = (obj1.selectOperation("from Emp e")).list();
		//obj1.closeConn();
		ModelAndView obj=new ModelAndView("showemp","key",lst);
        return obj;
    }
	@RequestMapping("showfeed")
    public ModelAndView showFeed(HttpServletRequest request)
    {
		 HttpSession session = request.getSession();
		 if(session.getAttribute("uid") != null)
		 {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		List lst = (obj1.selectOperation("from Feedback e")).list();
		//obj1.closeConn();
		ModelAndView obj=new ModelAndView("showfeed","key",lst);
        return obj;
		 }
	 
	 else
	 {
		  return new ModelAndView("redirect:login.do"); 
	 }
    }
	@RequestMapping("logout")
	public ModelAndView logout(HttpServletRequest request)
	{
		 HttpSession session = request.getSession();
		 session.removeAttribute("key");
		 session.invalidate();
		  return new ModelAndView("redirect:login.do"); 
		 
	}
	@RequestMapping("findemp")
    public ModelAndView findEmp(HttpServletRequest request)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		Query q = obj1.selectOperation("from Emp e where e.empid=?");
		q.setString(0,request.getParameter("q"));
		List lst = q.list();
		
		ModelAndView obj=new ModelAndView("findemp","key",lst);
        return obj;
    }
	@RequestMapping("updateemp")
    public ModelAndView updateEmp(HttpServletRequest request)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		Object o = obj1.findOperation(Emp.class,Integer.parseInt(request.getParameter("txtempid")));
		Emp e = (Emp)o;
		e.setEmpname(request.getParameter("txtempname"));
		e.setJob(request.getParameter("txtjob"));
		e.setSalary(Integer.parseInt(request.getParameter("txtsal")));
		obj1.updateOperation(e);
		obj1.closeConn();
		ModelAndView obj=new ModelAndView("redirect:showemp.do");
        return obj;
    }
	@RequestMapping("deleteemp")
    public ModelAndView deleteEmp(HttpServletRequest request)
    {
		Datahelper obj1 = new Datahelper();
		obj1.configure();
		Object o = obj1.findOperation(Emp.class,Integer.parseInt(request.getParameter("q")));
		Emp e = (Emp)o;
		obj1.deleteOperation(e);
		ModelAndView obj=new ModelAndView("redirect:showemp.do");
        return obj;
    }
   
}

