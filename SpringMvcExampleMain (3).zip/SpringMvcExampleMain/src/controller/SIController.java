package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.SIModel;

@Controller
public class SIController {
	
	@RequestMapping("sipath")
	
	public ModelAndView siLoad(@ModelAttribute("SpringMvcExampleMain")SIModel s, ModelMap model)
	{
		if(s!=null)
		{
			float si = (s.getP()*s.getR()*s.getT())/100;
			model.addAttribute("key", si);
		}
		return new ModelAndView("siview","command",new SIModel());
		
		
	}
}
